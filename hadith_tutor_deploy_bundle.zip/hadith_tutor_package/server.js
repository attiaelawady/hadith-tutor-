const express = require('express');
const multer = require('multer');
const path = require('path');
const fs = require('fs');
const app = express();
const upload = multer({ storage: multer.memoryStorage(), limits: { fileSize: 20 * 1024 * 1024 } });
app.use(express.json({limit:'2mb'}));
app.use(express.static(__dirname));
app.get('/api/status', (req,res)=>res.json({ready:!!process.env.OPENAI_API_KEY}));
app.post('/api/chat', async (req,res)=>{
  if(!process.env.OPENAI_API_KEY) return res.status(503).json({error:'لم يتم إعداد مفتاح الذكاء الاصطناعي على الخادم بعد. اتبع خطوات README.'});
  const {question, history=[], excerpts=[], mode='شرح'} = req.body || {};
  if(!question) return res.status(400).json({error:'اكتب السؤال أولاً.'});
  const context = excerpts.map((e,i)=>`[مقتطف ${i+1} | ${e.page ? 'صفحة '+e.page : ''}]\n${e.text}`).join('\n\n');
  const instructions = `أنت مدرس مساعد متخصص حصريًا في مادة الحديث للصف الأول الثانوي الأزهري، الفصل الدراسي الأول. مرجعك الأساسي هو كتاب الطالب الذي يرسل لك مقتطفاته في سياق السؤال.\n\nقواعد مهمة:\n- اعتمد على مقتطفات الكتاب المرفقة في الإجابة، ولا تخترع نصًا أو حكمًا أو نسبة حديث غير موجودة بالمصدر.\n- إذا لم تتوفر مقتطفات مناسبة أو لا يدعم الكتاب الجواب، صرّح بوضوح أن المعلومة غير ظاهرة في الجزء المرفق واطلب الصفحة/الدرس، ولا تخمّن.\n- اشرح بالعربية المصرية البسيطة عند التبسيط، مع إبقاء المصطلحات الشرعية/الحديثية كما هي، وعرّفها بلغة سهلة.\n- اشرح بتدرج: الفكرة، شرح النقاط، مثال مناسب، ثم خلاصة قصيرة. تجنب الإطالة إلا إذا طلب الطالب.\n- لا تحرّف الآيات أو الأحاديث ولا تقدّم فتوى خارج نطاق الدرس. عند عرض نص شرعي حرفيًا، كن حذرًا واذكر أنه من مقتطف الكتاب إن كان موجودًا.\n- في وضع ${mode}: إذا كان تسميعًا/اختبارًا، لا تكشف الإجابة قبل محاولة الطالب؛ صحح برفق وفسر الخطأ.\n- كن مشجعًا، ولا تعامل الطالب بتعالٍ.\n\nمقتطفات الكتاب المتاحة لهذا السؤال:\n${context || '(لا توجد مقتطفات كتاب مرفقة)'}\n`;
  const messages = (Array.isArray(history)?history:[]).slice(-10).map(m=>({role:m.role==='assistant'?'assistant':'user',content:String(m.content||'')}));
  messages.push({role:'user',content:String(question)});
  try {
    const r = await fetch('https://api.openai.com/v1/responses', {
      method:'POST', headers:{'Authorization':`Bearer ${process.env.OPENAI_API_KEY}`,'Content-Type':'application/json'},
      body:JSON.stringify({model:process.env.OPENAI_MODEL || 'gpt-4.1-mini',instructions,input:messages})
    });
    const data=await r.json();
    if(!r.ok) return res.status(r.status).json({error:data.error?.message || 'تعذر الاتصال بخدمة الذكاء الاصطناعي.'});
    const answer=data.output_text || (data.output||[]).flatMap(x=>x.content||[]).map(c=>c.text||'').join('') || 'لم يصل رد.';
    res.json({answer});
  } catch(e){res.status(500).json({error:'حدث خطأ أثناء الاتصال. تحقق من اتصال الإنترنت وإعداد الخادم.'});}
});
app.post('/api/transcribe', upload.single('audio'), async (req,res)=>{
  if(!process.env.OPENAI_API_KEY) return res.status(503).json({error:'خدمة تحويل الصوت غير مفعلة: أضف مفتاح API للخادم.'});
  if(!req.file) return res.status(400).json({error:'لم يتم استقبال ملف صوت.'});
  try {
    const form = new FormData();
    form.append('file',new Blob([req.file.buffer],{type:req.file.mimetype}),req.file.originalname || 'voice.webm');
    form.append('model','gpt-4o-mini-transcribe');
    form.append('language','ar');
    const r=await fetch('https://api.openai.com/v1/audio/transcriptions',{method:'POST',headers:{Authorization:`Bearer ${process.env.OPENAI_API_KEY}`},body:form});
    const data=await r.json(); if(!r.ok) return res.status(r.status).json({error:data.error?.message||'فشل تحويل الصوت إلى نص.'});
    res.json({text:data.text||''});
  }catch(e){res.status(500).json({error:'تعذر تحويل التسجيل. حاول مرة أخرى.'});}
});
app.get('/health',(req,res)=>res.send('Hadith tutor server running'));
const port=process.env.PORT||3000;
app.listen(port,()=>console.log(`Hadith tutor running at http://localhost:${port}`));
